<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reservation;
use App\Models\Product;
use Illuminate\Support\Str;

class ReservationController extends Controller
{
    // Listar reservas (usuario solo ve las suyas, admin ve todas)
    public function index(Request $request)
    {
        $user = $request->user();

        if ($user->role === 'admin') {
            return Reservation::with('user', 'product')->get();
        }

        return $user->reservations()->with('product')->get();
    }

    // Crear una reserva
    public function store(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
            'delivery_type' => 'required|in:retiro,domicilio',
            'delivery_address' => 'nullable|string'
        ]);

        $product = Product::findOrFail($request->product_id);

        if ($product->stock < $request->quantity) {
            return response()->json(['error' => 'Stock insuficiente'], 400);
        }

        $reservation = Reservation::create([
            'user_id' => $request->user()->id,
            'product_id' => $product->id,
            'quantity' => $request->quantity,
            'delivery_type' => $request->delivery_type,
            'delivery_address' => $request->delivery_type === 'domicilio' ? $request->delivery_address : null,
            'delivery_code' => $request->delivery_type === 'retiro' ? strtoupper(Str::random(8)) : null
        ]);

        // Descontar stock
        $product->stock -= $request->quantity;
        $product->save();

        return response()->json([
            'message' => 'Producto apartado exitosamente',
            'reservation' => $reservation
        ], 201);
    }
}
