<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class InventoryController extends Controller
{
    public function index()
    {
        $products = Product::select('id', 'name', 'category', 'stock', 'price')->get();

        return response()->json([
            'message' => 'Inventario actual',
            'data' => $products
        ]);
    }
}
